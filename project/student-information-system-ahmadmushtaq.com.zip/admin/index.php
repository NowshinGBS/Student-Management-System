<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Control Panel :: Student Information Panel:: Institute of Information Technology, BZU</title>
<style type="text/css">
<!--
.heading {
	color: #F90;
	font-family: "Comic Sans MS", cursive;
}
.options {
	font-family: "Comic Sans MS", cursive;
	font-size: 16px;
	font-style: oblique;
	color: #F93;
}
-->
</style>
</head>

<body background="images/1019286_abstract_orange_tiles_background_.jpg">

<br />
<br />
<br />
<table align="center" cellpadding="0" bgcolor="#FFFFFF" width="800" border="0">
  <tr>
    <td><h1 align="center" class="heading"><img src="images/cooltext457948700.png" width="747" height="58" alt="Welcome to Admin Panel" /></h1>
      <p align="center">&nbsp;</p>
      <table width="638" border="0" align="center">
        <tr>
          <td width="107"><a href="insert.php"><img border="0" name="test
     " src="images/cooltext457947887.png" onmouseover="this.src='images/cooltext457947887MouseOver.png';" onmouseout="this.src='images/cooltext457947887.png';" /></a></td>
          <td width="515" class="options">to enter a new student record...</td>
        </tr>
        <tr>
          <td><a href="delete.php"><img border="0" src="images/cooltext457947999.png" onmouseover="this.src='images/cooltext457947999MouseOver.png';" onmouseout="this.src='images/cooltext457947999.png';" /></a></td>
          <td class="options">to delete a student record..</td>
        </tr>
        <tr>
          <td><a href="modify.php"><img border="0" src="images/cooltext457948094.png" onmouseover="this.src='images/cooltext457948094MouseOver.png';" onmouseout="this.src='images/cooltext457948094.png';" /></a></td>
          <td class="options">to modify a student record...</td>
        </tr>
      </table>
      <p align="center"><a href="../about.php"><img src="images/cooltext457954859.png" alt="" border="0" onmouseover="this.src='images/cooltext457954859MouseOver.png';" onmouseout="this.src='images/cooltext457954859.png';" /></a><a href="../"><img border="0" src="images/cooltext457951462.png" alt="Go Back" onmouseover="this.src='images/cooltext457951462MouseOver.png';" onmouseout="this.src='images/cooltext457951462.png';" /></a><a href="http://www.ahmadmushtaq.com"><img src="images/cooltext457955210.png" alt="" border="0" onmouseover="this.src='images/cooltext457955210MouseOver.png';" onmouseout="this.src='images/cooltext457955210.png';" /></a></p>
    <p align="center"><a href="../about.php"><img border="0" src="images/ahmad.jpg" width="395" height="32" alt="Developed by Ahmad Mushtaq" /></a></p></td>
  </tr>
</table>
<h1 align="center" class="heading">&nbsp;</h1>
</body>
</html>